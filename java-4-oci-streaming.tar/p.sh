java -cp "/projects/kk-oss-producer-n-consumer/kafka_2.13-2.6.0/libs/*":. kkProducer

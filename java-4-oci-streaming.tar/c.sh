java -cp "/projects/kk-oss-producer-n-consumer/kafka_2.13-2.6.0/libs/*":"/projects/kk-oss-producer-n-consumer/jars.183/ojdbc8.jar":. kkConsumer


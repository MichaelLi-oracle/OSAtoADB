import java.util.Properties;
import java.util.Arrays;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.sql.Connection; 
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

public class kkConsumer {

   public static void main(String[] args) throws Exception {
      Class.forName("oracle.jdbc.OracleDriver");
      String topicName = System.getenv("STREAMING_NAME");
      String bootstrap = System.getenv("STREAMING_BOOTSTRAP");
      String jaas = System.getenv("STREAMING_JAAS");

      //Kafka Connection props
      Properties props = new Properties();
      props.put("bootstrap.servers", bootstrap);
      props.put("security.protocol", "SASL_SSL");
      props.put("sasl.mechanism", "PLAIN");
      props.put("sasl.jaas.config", jaas);
      props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
      props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

      props.put("group.id", "group-0");
      props.put("enable.auto.commit", "true");
      props.put("auto.commit.interval.ms", "1000");
      props.put("auto.offset.reset","earliest");
      props.put("session.timeout.ms", "30000");
      //
      KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
      consumer.subscribe(Arrays.asList(topicName));
      //
      System.out.println("===================================================");      
      System.out.println("Successfully subscribed to topic.");
      System.out.println("---------------------------------------------------");      

      //ADB Connectionprops
      String TNS_ADMIN_PATH = "./wallet";
      String DB_URL = "jdbc:oracle:thin:@db202011011043_low?TNS_ADMIN=" + TNS_ADMIN_PATH;
      String CONN_FACTORY_CLASS_NAME = "oracle.jdbc.pool.OracleDataSource";
      Properties prop_adb = new java.util.Properties();

      prop_adb.setProperty("user","connectdemo");
      prop_adb.setProperty("password","WelcomE__12345");
      prop_adb.setProperty("oracle.net.tns_admin",TNS_ADMIN_PATH);
      prop_adb.setProperty("javax.net.ssl.trustStore", TNS_ADMIN_PATH + "/" +  "truststore.jks");
      prop_adb.setProperty("javax.net.ssl.trustStorePassword","WelcomE__12345");
      prop_adb.setProperty("oracle.net.ssl_server_dn_match","true") ;
      prop_adb.setProperty("javax.net.ssl.keyStore",TNS_ADMIN_PATH + "/" +  "keystore.jks");
      prop_adb.setProperty("javax.net.ssl.keyStorePassword","WelcomE__12345");
      prop_adb.setProperty("oracle.net.ssl_version","1.2");
      //
      System.out.println("Connecting to ADB.");  
      Connection connection = DriverManager.getConnection(DB_URL , prop_adb);
      // Get the JDBC driver name and version
      DatabaseMetaData dbmd = connection.getMetaData();
      System.out.println("Driver Name: " + dbmd.getDriverName());
      System.out.println("Driver Version: " + dbmd.getDriverVersion());
      System.out.println("Successfully Connected. ");
      System.out.println("===================================================");
      //
      int i = 0;
      while (true) {
         ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {               
               System.out.println("Message retrieved from OCI Streaming:");
               System.out.printf("offset = %d, key = %s, value = %s\n",record.offset(), record.key(), record.value());
               System.out.println("---------------------------------------------------");
               try (Statement statement = connection.createStatement()) {
                  statement.executeUpdate("INSERT INTO KKTEST (message_body, created_on) " + "VALUES ('" + record.value()+ "', sysdate)"); 
               }               
               System.out.println("The mesage has been injected into ADB.");  
               // Statement and ResultSet are AutoCloseable and closed automatically.
               try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement
                       .executeQuery("select to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') current_date,count(*) from kktest")) {
                 while (resultSet.next())
                   // System.out.println("Today's Date is: " + resultSet.getString(1));
                  System.out.println("Current Time : " + resultSet.getString(1) +  " | Total ADB Records : " + resultSet.getString(2) );
                  System.out.println("---------------------------------------------------");
                }
               }
            }

      }
   }
}

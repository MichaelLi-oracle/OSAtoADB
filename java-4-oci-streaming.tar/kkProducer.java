import java.util.Properties;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;


public class kkProducer {

   public static void main(String[] args) throws Exception{

      String topicName = System.getenv("STREAMING_NAME");
      String bootstrap = System.getenv("STREAMING_BOOTSTRAP");
      String jaas = System.getenv("STREAMING_JAAS");


      Properties properties = new Properties();
      properties.put("bootstrap.servers", bootstrap);
      properties.put("security.protocol", "SASL_SSL");
      properties.put("sasl.mechanism", "PLAIN");
      properties.put("sasl.jaas.config", jaas);
      properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
      properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

      Producer<String, String> producer = new KafkaProducer<String, String>(properties);
      System.out.println("Message being sent ...");
      for(int i = 0; i < 10; i++) {
         producer.send(new ProducerRecord<String, String>(topicName, null, "{\"test\":\"" + Integer.toString(i) + "\"}"));
         System.out.println("Message No. " + Integer.toString(i) + " is done.");
      }
      System.out.println("Message sent successfully.");
      producer.flush();
      producer.close();
   }
}
